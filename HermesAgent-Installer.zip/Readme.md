# 🦞🪽 愛馬仕龍蝦 HermesAgent 一鍵安裝精靈 V1.0

> 將 [HermesAgent](https://github.com/NousResearch/hermes-agent)（Nous Research 開源 AI Agent）串接 **Telegram** 或 **LINE Bot**，透過 **ngrok** 暴露 Webhook，一鍵自動完成！

---

## 🌐 教學網站

**https://hermes-lobster.netlify.app**

完整教學網站，包含：使用情境、Windows/Mac 安裝教學、Telegram/LINE 設定、指令速查

---

## 🚀 快速開始

1. 對 **`go.bat`** 按右鍵 → **以系統管理員身分執行**
2. 選擇 **[1] 全部安裝**，跟著精靈走即可！

---

## 📋 系統需求

| 項目 | 需求 |
|------|------|
| 作業系統 | Windows 10/11（64位元）|
| BIOS 設定 | 虛擬化（VT-x / AMD-V）已啟用 |
| 磁碟空間 | 至少 10 GB 可用空間 |
| 記憶體 | 至少 8 GB RAM（建議 16 GB）|
| 網路 | 需要網際網路連線 |

---

## 🏗️ 架構說明

```
┌─────────────────────────────────────────────────────────┐
│                     Windows 11                          │
│                                                         │
│  📱 Telegram ←──→ HermesAgent（WSL2, Port 8080）        │
│                        ↕（Polling 模式，免 ngrok）       │
│                                                         │
│  📱 LINE Bot ──→ ngrok（Port 3000）                     │
│                    ↕                                    │
│            LINE Bridge（Windows, Port 3000）            │
│                    ↕                                    │
│            HermesAgent（WSL2, Port 8080）               │
└─────────────────────────────────────────────────────────┘
```

---

## 📁 檔案結構

```
HermesAgent一鍵自動安裝程式/
├── go.bat                  ← 🚪 安裝入口（管理員執行）
├── install-hermes.ps1      ← 🤖 主安裝腳本
├── Readme.md               ← 📖 本說明文件
├── 參考.txt                ← 📚 教學參考資料
└── bridge/                 ← 🌉 LINE Bridge（Node.js）
    ├── line-bridge.js      ← LINE Webhook → Hermes API
    ├── package.json        ← Node.js 相依套件
    └── .env.example        ← 設定檔範本
```

---

## 🔧 安裝流程

### Phase 1：WSL2 安裝
- 自動偵測 CPU 虛擬化
- 執行 `wsl --install` 安裝 WSL2 + Ubuntu
- **需要重新開機一次**，完成後再次執行 `go.bat`

### Phase 2：HermesAgent 安裝
- 在 WSL2 內執行官方安裝腳本（約 15-20 分鐘）
- 選擇 AI 大腦（四種方案）：

| 方案 | 條件 | 費用 |
|------|------|------|
| **Anthropic → Claude Code OAuth** | 有 Claude Pro/Max 訂閱 | 吃月費，不另付 |
| **OpenAI → OpenAI OAuth** | 有 ChatGPT Plus/Pro 訂閱 | 吃月費，不另付 |
| **Nous Portal** | 無訂閱，想免費試用 | 免費兩週（MiMo） |
| **OpenRouter / 其他** | 有 API Key | 按用量付費 |

### Phase 3A：Telegram 機器人設定
- 向 [@BotFather](https://t.me/BotFather) 申請 Bot Token
- 向 [@userinfobot](https://t.me/userinfobot) 取得 User ID
- **不需要 ngrok！** 使用 Polling 模式，隨開即用

### Phase 3B：LINE 機器人設定
- 在 [LINE Developers Console](https://developers.line.biz/) 建立 Messaging API Channel
- 取得 Channel Secret 和 Access Token
- 安裝精靈自動建立 `bridge/.env`

### Phase 4：ngrok 設定（LINE 必須）
- 下載並安裝 ngrok
- 設定 Authtoken（免費帳號）
- 啟動隧道，自動取得公開 HTTPS URL

### Phase 5：啟動服務
- 自動啟動 HermesAgent Gateway（WSL2）
- 自動啟動 LINE Bridge（Windows，若有設定 LINE）
- 自動啟動 ngrok 隧道（若有設定 LINE）

---

## 🛠️ 手動操作指令

### WSL2 內（HermesAgent）
```bash
hermes gateway          # 啟動 Gateway
hermes gateway status   # 查看狀態
hermes chat             # 終端機對話
hermes --version        # 版本資訊
```

### Windows（LINE Bridge）
```powershell
cd bridge
npm start               # 啟動 LINE Bridge
```

### ngrok
```powershell
ngrok http 3000         # 為 LINE Bridge 建立隧道
ngrok http 8080         # 為 Hermes Gateway 建立隧道（Telegram Webhook 模式）
```

---

## ❓ 常見問題

**Q: 安裝 WSL2 後重開機，再次執行 go.bat，安裝精靈知道要從哪裡繼續嗎？**  
A: 是的，精靈會自動偵測 WSL2/HermesAgent 狀態，從上次中斷的地方繼續。

**Q: LINE 回覆很慢怎麼辦？**  
A: 確認 `hermes gateway` 在 WSL2 中正常運行。可以用 `http://localhost:3000/test` 測試連線。

**Q: Telegram Polling 模式和 Webhook 模式有什麼差別？**  
A: Polling 模式（預設）不需要 ngrok，HermesAgent 主動向 Telegram 拉取訊息；Webhook 模式需要 ngrok，由 Telegram 主動推送。

**Q: 如何更新 HermesAgent？**  
A: 在 WSL2 執行：`hermes update`

---

## 📝 版本紀錄

| 版本 | 日期 | 更新內容 |
|------|------|---------|
| V1.0 | 2026-04-11 | 初始版本，WSL2 + Telegram + LINE + ngrok |

---

---

## 🎯 HermesAgent 適合什麼？

**HermesAgent 不是單純聊天工具，而是通用型 AI Agent 平台。**

| ✅ 適合的場景 | ❌ 不適合的場景 |
|-------------|--------------|
| 多步驟自動化工作流 | 需要毫秒級即時回應 |
| 長期持續使用（記憶積累） | 無邊界高權限全自動執行 |
| 跨 Telegram/LINE 多平台接入 | 替代確定性核心商業邏輯 |
| 定期自動化任務（cron） | |
| 整合多個外部系統（MCP） | |

**核心架構三層：**
```
擴展生態層  ── skills、MCP、插件、自訂工具
平台能力層  ── CLI、Gateway、排程、設定、權限
Agent 執行層 ── 對話循環、工具調度、上下文壓縮
```

---

## 👨‍🏫 關於作者

<div align="center">

### 曾慶良 主任（阿亮老師）

<table>
<tr>
<td width="50%">

**📌 現任職務**

🎓 新興科技推廣中心主任<br>
🎓 教育部學科中心研究教師<br>
🎓 臺北市資訊教育輔導員

</td>
<td width="50%">

**🏆 獲獎紀錄**

🥇 2025年 SETEAM教學專業講師認證<br>
🥇 2024年 教育部人工智慧講師認證<br>
🥇 2022、2023年 指導學生XR專題競賽特優<br>
🥇 2022年 VR教材開發教師組特優<br>
🥇 2019年 百大資訊人才獎<br>
🥇 2018、2019年 親子天下創新100教師<br>
🥇 2018年 臺北市特殊優良教師<br>
🥇 2017年 教育部行動學習優等

</td>
</tr>
</table>

<br>

### 📞 聯絡方式

[![YouTube](https://img.shields.io/badge/YouTube-@Liang--yt02-red?style=for-the-badge&logo=youtube)](https://www.youtube.com/@Liang-yt02)
[![Facebook](https://img.shields.io/badge/Facebook-3A科技研究社-blue?style=for-the-badge&logo=facebook)](https://www.facebook.com/groups/2754139931432955)
[![Email](https://img.shields.io/badge/Email-3a01chatgpt@gmail.com-green?style=for-the-badge&logo=gmail)](mailto:3a01chatgpt@gmail.com)

</div>

---

## 📜 授權聲明

**© 2026 曾慶良（阿亮老師）版權所有**

本安裝精靈腳本（`install-hermes.ps1`、`go.bat`、`bridge/line-bridge.js`）由**阿亮老師**開發，僅供阿亮老師課程學員個人學習使用。

> HermesAgent 本體（`github.com/NousResearch/hermes-agent`）採 MIT 授權，由 NousResearch 開發。

### ⚠️ 禁止事項

- ❌ 禁止修改本安裝精靈內容
- ❌ 禁止轉傳或散布
- ❌ 禁止商業使用
- ❌ 禁止未經授權之任何形式重製或公開傳輸

如有授權需求，請聯繫作者：3a01chatgpt@gmail.com

---

<div align="center">

**🦞🪽 Made with ❤️ by 阿亮老師（曾慶良）**

[⬆️ 回到頂部](#-愛馬仕龍蝦-hermesagent-一鍵安裝精靈-v10)

---

© 2026 曾慶良 版權所有

</div>
