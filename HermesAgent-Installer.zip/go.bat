@echo off
chcp 65001 >nul 2>&1

title HermesAgent 愛馬仕助理 安裝精靈 V1.0

echo.
echo   +============================================================+
echo   ^|  [ HermesAgent ] 愛馬仕龍蝦 一鍵安裝精靈 V1.0             ^|
echo   ^|       Hermes + Telegram / LINE + ngrok                    ^|
echo   +------------------------------------------------------------+
echo   ^|  作者：曾慶良（阿亮老師）  ^|  3a01chatgpt@gmail.com       ^|
echo   ^|  (c) 2026 曾慶良  版權所有  ^|  僅供課程學員學習使用        ^|
echo   +============================================================+
echo.

rem --- 確認以系統管理員身分執行 ---
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo   [警告] 請以「系統管理員身分執行」此程式！
    echo.
    echo   操作方式：對此 go.bat 按右鍵 -^> 以系統管理員身分執行
    echo.
    pause
    exit /b 1
)

echo   [OK] 已確認管理員權限，啟動安裝精靈...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-hermes.ps1"

echo.
echo   安裝程序已結束。
pause
