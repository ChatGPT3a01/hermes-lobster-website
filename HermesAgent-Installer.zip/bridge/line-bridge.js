/**
 * ============================================================
 *  🦞🪽 愛馬仕龍蝦 HermesAgent LINE Bridge
 *  版本：V1.0  日期：2026-04-11
 *
 *  作者：曾慶良（阿亮老師）
 *  職務：新興科技推廣中心主任 / 教育部學科中心研究教師
 *  信箱：3a01chatgpt@gmail.com
 *  YouTube：https://www.youtube.com/@Liang-yt02
 *  FB社團：https://www.facebook.com/groups/2754139931432955
 *
 *  © 2026 曾慶良 版權所有
 *  本程式僅供阿亮老師課程學員個人學習使用。
 *  禁止修改、轉傳、商業使用或未經授權散布。
 *
 *  HermesAgent 本體：MIT License by NousResearch
 *  github.com/NousResearch/hermes-agent
 * ============================================================
 *
 *  LINE Bot Webhook → HermesAgent OpenAI-compatible API → LINE Reply
 *
 *  設定：複製 .env.example 為 .env 並填入你的金鑰
 *  啟動：node line-bridge.js
 */

require('dotenv').config();
const express = require('express');
const line = require('@line/bot-sdk');
const { OpenAI } = require('openai');

// ============================================================
//  設定
// ============================================================
const config = {
  channelSecret:      process.env.LINE_CHANNEL_SECRET || '',
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN || '',
};

const HERMES_API_URL = process.env.HERMES_API_URL || 'http://localhost:8080/v1/chat/completions';
const BRIDGE_PORT    = parseInt(process.env.BRIDGE_PORT || '3000');
const BOT_NAME       = process.env.BOT_NAME || '愛馬仕助理';
const SYSTEM_PROMPT  = process.env.SYSTEM_PROMPT ||
  '你是一位聰明、親切的 AI 助理。請用繁體中文回答。';

// 驗證必要設定
if (!config.channelSecret || !config.channelAccessToken) {
  console.error('[錯誤] 缺少 LINE_CHANNEL_SECRET 或 LINE_CHANNEL_ACCESS_TOKEN！');
  console.error('       請檢查 bridge/.env 檔案。');
  process.exit(1);
}

// ============================================================
//  初始化
// ============================================================
const lineClient = new line.messagingApi.MessagingApiClient({
  channelAccessToken: config.channelAccessToken,
});

// HermesAgent OpenAI-compatible client
// 官方確認：port 8642，API key 預設 "change-me-local-dev"
const hermes = new OpenAI({
  baseURL: HERMES_API_URL.replace('/chat/completions', ''),
  apiKey: process.env.HERMES_API_KEY || 'change-me-local-dev',
  timeout: 60000,
});

// 對話歷史（依 userId 保存，最多保留 20 輪）
const conversationHistory = new Map();
const MAX_HISTORY = 20;

// ============================================================
//  向 HermesAgent 發送訊息
// ============================================================
async function askHermes(userId, userMessage) {
  // 取得或建立對話歷史
  if (!conversationHistory.has(userId)) {
    conversationHistory.set(userId, []);
  }
  const history = conversationHistory.get(userId);

  // 加入使用者訊息
  history.push({ role: 'user', content: userMessage });

  try {
    const response = await hermes.chat.completions.create({
      model: 'hermes',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...history.slice(-MAX_HISTORY * 2),  // 保留最近幾輪
      ],
      max_tokens: 1000,
      temperature: 0.7,
    });

    const reply = response.choices[0]?.message?.content || '（無回應）';

    // 儲存 assistant 回覆
    history.push({ role: 'assistant', content: reply });

    // 限制歷史長度
    if (history.length > MAX_HISTORY * 2) {
      history.splice(0, 2);  // 移除最舊的一輪對話
    }

    return reply;
  } catch (err) {
    console.error('[Hermes API 錯誤]', err.message);

    // 如果是連線錯誤，給友善提示
    if (err.code === 'ECONNREFUSED') {
      return `⚠️ 無法連接到 HermesAgent！\n\n請確認：\n1. WSL2 已開啟\n2. 在 WSL2 終端執行：hermes gateway\n3. 等待 Gateway 啟動後再試`;
    }
    return `抱歉，發生錯誤：${err.message}`;
  }
}

// ============================================================
//  處理 LINE 事件
// ============================================================
async function handleEvent(event) {
  // 只處理文字訊息
  if (event.type !== 'message' || event.message.type !== 'text') {
    return null;
  }

  const userMessage = event.message.text.trim();
  const userId = event.source.userId;

  console.log(`[收到] userId=${userId} | 訊息：${userMessage}`);

  // 特殊指令
  if (userMessage === '/clear' || userMessage === '清除記憶') {
    conversationHistory.delete(userId);
    return lineClient.replyMessage({
      replyToken: event.replyToken,
      messages: [{ type: 'text', text: '✅ 對話記憶已清除！' }],
    });
  }

  if (userMessage === '/help' || userMessage === '說明') {
    const helpText = `🦞🪽 ${BOT_NAME} 指令說明\n\n` +
      `/clear - 清除對話記憶\n` +
      `/status - 查看服務狀態\n` +
      `/help - 顯示此說明\n\n` +
      `直接輸入任何文字即可開始對話！`;
    return lineClient.replyMessage({
      replyToken: event.replyToken,
      messages: [{ type: 'text', text: helpText }],
    });
  }

  if (userMessage === '/status') {
    const histCount = (conversationHistory.get(userId) || []).length / 2;
    const statusText = `📊 服務狀態\n\n` +
      `🟢 LINE Bridge：運行中（Port ${BRIDGE_PORT}）\n` +
      `💬 你的對話輪數：${Math.floor(histCount)}\n` +
      `🤖 HermesAgent：${HERMES_API_URL}`;
    return lineClient.replyMessage({
      replyToken: event.replyToken,
      messages: [{ type: 'text', text: statusText }],
    });
  }

  // 發送到 HermesAgent
  const reply = await askHermes(userId, userMessage);
  console.log(`[回覆] ${reply.substring(0, 80)}...`);

  return lineClient.replyMessage({
    replyToken: event.replyToken,
    messages: [{ type: 'text', text: reply }],
  });
}

// ============================================================
//  Express 伺服器
// ============================================================
const app = express();

// LINE Webhook（使用 LINE 簽名驗證中間件）
app.post('/webhook',
  line.middleware(config),
  (req, res) => {
    Promise.all(req.body.events.map(handleEvent))
      .then(() => res.status(200).json({ status: 'ok' }))
      .catch((err) => {
        console.error('[Webhook 錯誤]', err);
        res.status(500).end();
      });
  }
);

// 健康檢查
app.get('/', (req, res) => {
  res.json({
    service: `${BOT_NAME} LINE Bridge`,
    status: 'running',
    port: BRIDGE_PORT,
    hermes_api: HERMES_API_URL,
    webhook_path: '/webhook',
    active_users: conversationHistory.size,
  });
});

// 測試端點（手動觸發）
app.get('/test', async (req, res) => {
  const testMsg = req.query.msg || '你好！';
  try {
    const reply = await askHermes('test-user', testMsg);
    res.json({ input: testMsg, output: reply });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
//  啟動
// ============================================================
app.listen(BRIDGE_PORT, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════════════════════╗');
  console.log(`  ║  🦞🪽  ${BOT_NAME} LINE Bridge 啟動成功！            ║`);
  console.log('  ╠══════════════════════════════════════════════════════╣');
  console.log(`  ║  監聽 Port   : ${BRIDGE_PORT}                                   ║`);
  console.log(`  ║  Webhook 路徑: /webhook                              ║`);
  console.log(`  ║  Hermes API  : ${HERMES_API_URL}   ║`);
  console.log('  ╠══════════════════════════════════════════════════════╣');
  console.log('  ║  操作說明：                                          ║');
  console.log('  ║  1. 確認 WSL2 已執行：hermes gateway                 ║');
  console.log('  ║  2. 確認 ngrok 已啟動：ngrok http 3000               ║');
  console.log('  ║  3. 將 ngrok URL + /webhook 填入 LINE Console        ║');
  console.log('  ║  4. 測試：http://localhost:3000/test?msg=你好         ║');
  console.log('  ╚══════════════════════════════════════════════════════╝');
  console.log('');
});

// 優雅關閉
process.on('SIGINT', () => {
  console.log('\n  LINE Bridge 已關閉。掰掰！🦞');
  process.exit(0);
});
