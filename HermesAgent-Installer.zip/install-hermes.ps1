# ============================================================
#  [HermesAgent] 愛馬仕龍蝦 一鍵安裝精靈 V1.0
#  WSL2 + Hermes Agent + Telegram / LINE Bridge + ngrok
#  作者：曾慶良（阿亮老師）
#  HermesAgent 開源專案：github.com/NousResearch/hermes-agent
#
#  用法：對 go.bat 按右鍵 → 以系統管理員身分執行
# ============================================================

# --- 編碼設定（確保中文正常顯示）---
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
chcp 65001 | Out-Null

# --- 全域變數 ---
$SCRIPT_DIR       = Split-Path -Parent $MyInvocation.MyCommand.Path
$BRIDGE_DIR       = Join-Path $SCRIPT_DIR "bridge"
$STATE_FILE       = Join-Path $env:TEMP "hermes-installer-state.json"
$HERMES_PORT      = 8642   # Hermes gateway 預設 port（官方確認：127.0.0.1:8642）
$BRIDGE_PORT      = 3000   # LINE Bridge port（Windows 本機）
$NGROK_DIR        = "C:\tools\ngrok"
$NGROK_EXE        = Join-Path $NGROK_DIR "ngrok.exe"

# Windows 原生安裝路徑（官方 install.ps1 預設）
$HERMES_WIN_HOME  = Join-Path $env:LOCALAPPDATA "hermes"
$HERMES_WIN_AGENT = Join-Path $HERMES_WIN_HOME "hermes-agent"
$HERMES_WIN_ENV   = Join-Path $HERMES_WIN_HOME ".env"
$HERMES_WIN_EXE   = Join-Path $HERMES_WIN_AGENT "venv\Scripts\hermes.exe"

# ============================================================
#  工具函式
# ============================================================
function Refresh-Path {
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" +
                [System.Environment]::GetEnvironmentVariable("Path","User")
}

function Write-CopyrightNotice {
    $notice = @"

  ╔══════════════════════════════════════════════════════════════════════╗
  ║                                                                      ║
  ║                      著  作  權  聲  明                              ║
  ║                                                                      ║
  ╠══════════════════════════════════════════════════════════════════════╣
  ║                                                                      ║
  ║  本軟體著作權為  曾慶良（阿亮老師）  所有，                          ║
  ║  受中華民國著作權法及國際著作權條約保護。                            ║
  ║                                                                      ║
  ║  作者：曾慶良（阿亮老師）                                            ║
  ║  職務：新興科技推廣中心主任 ／ 教育部學科中心研究教師                ║
  ║        臺北市資訊教育輔導員                                          ║
  ║  信箱：3a01chatgpt@gmail.com                                        ║
  ║                                                                      ║
  ║  HermesAgent 本體：MIT 授權（NousResearch）                          ║
  ║  本安裝精靈腳本：© 2026 曾慶良  版權所有                             ║
  ║                                                                      ║
  ║  ⚠  未經書面授權，嚴禁下列行為：                                    ║
  ║     • 重製、散布、公開傳輸或改作本軟體之全部或部分                   ║
  ║     • 移除或竄改本著作權聲明                                         ║
  ║     • 將本軟體用於商業營利目的                                       ║
  ║     • 以任何形式提供第三方下載或轉發                                 ║
  ║                                                                      ║
  ║  本軟體僅限阿亮老師課程學員個人學習使用。                            ║
  ║                                                                      ║
  ╚══════════════════════════════════════════════════════════════════════╝

"@
    Write-Host $notice -ForegroundColor Red
    Write-Host "  按 Enter 表示您已閱讀並同意上述著作權聲明..." -ForegroundColor DarkGray
    Read-Host | Out-Null
}

function Write-Banner {
    Clear-Host
    $banner = @"

  ╔════════════════════════════════════════════════════════════════╗
  ║                                                                ║
  ║   [ HermesAgent ]  愛馬仕龍蝦  一鍵安裝精靈                   ║
  ║                                                                ║
  ║       Hermes Agent  +  Telegram / LINE  +  ngrok  V1.0        ║
  ║                                                                ║
  ║   由 NousResearch 開發  |  MIT 開源授權                        ║
  ║   安裝精靈由 阿亮老師（曾慶良）改編                            ║
  ║                                                                ║
  ╚════════════════════════════════════════════════════════════════╝

"@
    Write-Host $banner -ForegroundColor Cyan
}

function Write-Title($text) {
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "    $text" -ForegroundColor Cyan
    Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Step($text)   { Write-Host "  [步驟] $text" -ForegroundColor Yellow }
function Write-Ok($text)     { Write-Host "  [完成] $text" -ForegroundColor Green }
function Write-Err($text)    { Write-Host "  [錯誤] $text" -ForegroundColor Red }
function Write-Info($text)   { Write-Host "  [資訊] $text" -ForegroundColor Gray }
function Write-Warn($text)   { Write-Host "  [警告] $text" -ForegroundColor DarkYellow }
function Write-Highlight($t) { Write-Host "  $t" -ForegroundColor Magenta }

function Pause-Script($prompt = "  按 Enter 繼續...") {
    Write-Host ""
    Write-Host $prompt -ForegroundColor DarkGray
    Read-Host | Out-Null
}

function Copy-ToClipboard($text) {
    try {
        Set-Clipboard -Value $text
        Write-Info "已自動複製到剪貼簿！"
    } catch {
        Write-Info "請手動複製上方內容。"
    }
}

# ============================================================
#  知識技能自動部署
# ============================================================
function Deploy-KnowledgeSkill {
    $skillSrc = Join-Path $SCRIPT_DIR "SKILL\hermes-lobster-knowledge\SKILL.md"
    if (-not (Test-Path $skillSrc)) {
        Write-Warn "知識技能檔案未找到，略過部署。"
        return
    }

    Write-Step "部署愛馬仕龍蝦知識技能..."

    # Windows 原生路徑
    $winSkillDir = Join-Path $HERMES_WIN_HOME "skills\hermes-lobster-knowledge"
    try {
        New-Item -ItemType Directory -Path $winSkillDir -Force | Out-Null
        Copy-Item $skillSrc -Destination $winSkillDir -Force
        Write-Ok "知識技能已部署到：$winSkillDir"
    } catch {
        Write-Warn "Windows 路徑部署失敗，嘗試 WSL2..."
    }

    # WSL2 路徑（若有安裝）
    $wslCheck = wsl -e bash -c "echo ok" 2>$null
    if ($wslCheck -eq "ok") {
        $wslSkillDir = "~/.hermes/skills/hermes-lobster-knowledge"
        $wslSrcPath = $skillSrc -replace '\\', '/' -replace '^([A-Za-z]):', '/mnt/$1'.ToLower()
        wsl bash -c "mkdir -p $wslSkillDir && cp '$wslSrcPath' $wslSkillDir/SKILL.md" 2>$null
        Write-Ok "知識技能已部署到 WSL2：$wslSkillDir"
    }
}

# ============================================================
#  狀態管理（跨重開機持久化）
# ============================================================
function Save-State($state) {
    $state | ConvertTo-Json | Set-Content $STATE_FILE -Encoding UTF8
}

function Load-State {
    if (Test-Path $STATE_FILE) {
        $obj = Get-Content $STATE_FILE -Raw | ConvertFrom-Json
        # 統一轉成 Hashtable，避免 PSCustomObject 無法動態加屬性
        $ht = @{}
        $obj.PSObject.Properties | ForEach-Object { $ht[$_.Name] = $_.Value }
        return $ht
    }
    return @{
        wsl2_installed   = $false
        hermes_installed = $false
        telegram_set     = $false
        line_set         = $false
        ngrok_set        = $false
    }
}

function Clear-State {
    if (Test-Path $STATE_FILE) { Remove-Item $STATE_FILE -Force }
}

# ============================================================
#  安裝模式選擇（Windows 原生 vs WSL2）
# ============================================================
function Choose-InstallMode {
    Write-Title "選擇安裝模式"
    Write-Host "  HermesAgent 支援兩種安裝方式：" -ForegroundColor White
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║  [W] Windows 原生安裝（推薦！）                     ║" -ForegroundColor Cyan
    Write-Host "  ║      ✅ 不需要 WSL2，直接在 Windows 上運行          ║" -ForegroundColor Cyan
    Write-Host "  ║      ✅ 自動安裝 Python、Node.js 等依賴              ║" -ForegroundColor Cyan
    Write-Host "  ║      ✅ 設定路徑：%LOCALAPPDATA%\hermes\            ║" -ForegroundColor Cyan
    Write-Host "  ╠══════════════════════════════════════════════════════╣" -ForegroundColor Cyan
    Write-Host "  ║  [L] WSL2 Linux 環境安裝                            ║" -ForegroundColor Cyan
    Write-Host "  ║      需先安裝 WSL2 + Ubuntu（需重開機）             ║" -ForegroundColor Cyan
    Write-Host "  ║      適合熟悉 Linux 或已有 WSL2 的用戶              ║" -ForegroundColor Cyan
    Write-Host "  ╚══════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""

    while ($true) {
        $m = Read-Host "  請選擇 [W/L]"
        if ($m -match "^[Ww]$") {
            $state = Load-State
            $state.install_mode = "windows"
            Save-State $state
            Write-Ok "已選擇：Windows 原生安裝"
            return "windows"
        } elseif ($m -match "^[Ll]$") {
            $state = Load-State
            $state.install_mode = "wsl2"
            Save-State $state
            Write-Ok "已選擇：WSL2 Linux 環境"
            return "wsl2"
        }
        Write-Warn "請輸入 W 或 L"
    }
}

# ============================================================
#  Phase 1：WSL2 檢查與安裝
# ============================================================
function Test-WSL2 {
    try {
        $wslOutput = wsl --list --verbose 2>&1
        if ($LASTEXITCODE -eq 0 -and $wslOutput -match "Ubuntu") {
            return $true
        }
    } catch {}
    return $false
}

function Test-Virtualization {
    $virt = Get-WmiObject -Class Win32_Processor | Select-Object -ExpandProperty VirtualizationFirmwareEnabled
    return ($virt -eq $true)
}

function Install-WSL2 {
    Write-Title "Phase 1：安裝 WSL2（AI 專屬安全套房）"

    # 檢查虛擬化
    Write-Step "檢查 CPU 虛擬化功能..."
    $isVirtEnabled = Test-Virtualization
    if (-not $isVirtEnabled) {
        Write-Warn "CPU 虛擬化尚未啟用！"
        Write-Host ""
        Write-Host "  請按照以下步驟開啟虛擬化：" -ForegroundColor Yellow
        Write-Host "  1. 重新開機，開機時狂按 Del 或 F2 進入 BIOS" -ForegroundColor White
        Write-Host "  2. 尋找「Intel VT-x」或「AMD SVM」，設為 Enabled" -ForegroundColor White
        Write-Host "  3. 儲存並重啟後，再執行此安裝程式" -ForegroundColor White
        Write-Host ""
        Pause-Script "  確認已了解後按 Enter..."
        return $false
    }
    Write-Ok "CPU 虛擬化已啟用！"

    if (Test-WSL2) {
        Write-Ok "WSL2 + Ubuntu 已安裝！跳過此步驟。"
        return $true
    }

    Write-Step "開始安裝 WSL2 + Ubuntu..."
    Write-Warn "安裝完成後需要重新開機，請先儲存其他工作中的文件！"
    Write-Host ""
    Write-Host "  即將執行：wsl --install" -ForegroundColor White
    Pause-Script "  確認後按 Enter 開始安裝..."

    try {
        wsl --install
        Write-Ok "WSL2 安裝指令已執行！"
        Write-Host ""
        Write-Host "  ╔══════════════════════════════════════════════════════╗" -ForegroundColor Yellow
        Write-Host "  ║  ⚠  需要重新開機！請依照以下步驟操作：              ║" -ForegroundColor Yellow
        Write-Host "  ║                                                      ║" -ForegroundColor Yellow
        Write-Host "  ║  1. 按 Enter 後電腦會重新開機                        ║" -ForegroundColor Yellow
        Write-Host "  ║  2. 重開機後 Ubuntu 會自動安裝（需等幾分鐘）         ║" -ForegroundColor Yellow
        Write-Host "  ║  3. 設定 Linux 帳號密碼（輸入密碼時畫面不顯示）      ║" -ForegroundColor Yellow
        Write-Host "  ║  4. Ubuntu 設定完成後，再次執行 go.bat               ║" -ForegroundColor Yellow
        Write-Host "  ╚══════════════════════════════════════════════════════╝" -ForegroundColor Yellow
        Write-Host ""

        # 儲存狀態
        $state = Load-State
        $state.wsl2_installed = $false
        Save-State $state

        Pause-Script "  按 Enter 重新開機..."
        Restart-Computer -Force
    } catch {
        Write-Err "WSL2 安裝失敗：$($_.Exception.Message)"
        return $false
    }
    return $false
}

# ============================================================
#  Phase 2：安裝 HermesAgent
# ============================================================
function Test-HermesInstalled {
    # 先檢查 Windows 原生（PATH 或固定路徑）
    Refresh-Path
    $hermesCmd = Get-Command hermes -ErrorAction SilentlyContinue
    if ($hermesCmd) { return $true }
    if (Test-Path $HERMES_WIN_EXE) { return $true }

    # 再檢查 WSL2
    try {
        $result = wsl bash -c "which hermes 2>/dev/null" 2>&1
        if ($result -match "/hermes") { return $true }
    } catch {}

    return $false
}

function Fix-WindowsStatusBug {
    # 修復 Windows 版 status.py 的 OSError bug（騰訊雲文章記載的已知問題）
    $statusPy = Join-Path $HERMES_WIN_AGENT "gateway\status.py"
    if (-not (Test-Path $statusPy)) { return }

    $content = Get-Content $statusPy -Raw -Encoding UTF8
    if ($content -match "OSError") { return }  # 已修復，跳過

    $fixed = $content -replace 'except \(ProcessLookupError, PermissionError\):',
                                'except (ProcessLookupError, PermissionError, OSError):'
    Set-Content $statusPy -Value $fixed -Encoding UTF8
    Write-Ok "已修復 Windows status.py OSError 已知問題"
}

function Install-HermesWindows {
    Write-Title "Phase 2：Windows 原生安裝 HermesAgent"

    if (Test-HermesInstalled) {
        Write-Ok "HermesAgent 已安裝！"
        Refresh-Path
        $ver = hermes --version 2>&1
        Write-Info "版本：$ver"
        return $true
    }

    Write-Step "確認 Git 已安裝（必要條件）..."
    $gitCmd = Get-Command git -ErrorAction SilentlyContinue
    if (-not $gitCmd) {
        Write-Err "尚未安裝 Git！請先安裝 Git for Windows："
        Write-Host "  https://git-scm.com/download/win" -ForegroundColor Cyan
        Write-Host "  或執行：winget install Git.Git" -ForegroundColor White
        Pause-Script "  安裝完成後按 Enter 繼續..."
        try { winget install Git.Git --silent --accept-package-agreements } catch {}
        Refresh-Path
    }
    Write-Ok "Git 已就緒"

    Write-Warn "安裝約需 15-20 分鐘，過程中請勿關閉視窗。"
    Write-Host ""
    Write-Host "  即將執行官方 Windows 安裝腳本：" -ForegroundColor White
    Write-Host "  irm .../install.ps1 | iex" -ForegroundColor Gray
    Pause-Script "  確認後按 Enter 開始安裝..."

    # 設定 UTF-8（避免中文亂碼）
    $env:PYTHONUTF8 = "1"

    try {
        $installScript = Invoke-RestMethod `
            "https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.ps1"
        Invoke-Expression $installScript
    } catch {
        Write-Err "安裝腳本執行失敗：$($_.Exception.Message)"
        Write-Info "請嘗試手動在 PowerShell 執行："
        Write-Host "  irm https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.ps1 | iex" -ForegroundColor White
        Copy-ToClipboard "irm https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.ps1 | iex"
        Pause-Script "  手動執行完成後按 Enter 繼續..."
    }

    Refresh-Path
    Start-Sleep -Seconds 2

    # 修復已知 Windows bug
    Fix-WindowsStatusBug

    if (Test-HermesInstalled) {
        Write-Ok "HermesAgent Windows 原生安裝成功！"
        return $true
    } else {
        Write-Warn "安裝後未偵測到 hermes 指令，可能需要重新開啟 PowerShell。"
        $ans = Read-Host "  確認已安裝完成？繼續 (Y/N)"
        return ($ans -match "^[Yy]$")
    }
}

function Install-HermesInWSL {
    Write-Title "Phase 2：安裝 HermesAgent（愛馬仕助理本體）"

    if (Test-HermesInstalled) {
        Write-Ok "HermesAgent 已在 WSL2 中安裝！"
        $ver = wsl bash -c "hermes --version 2>/dev/null" 2>&1
        Write-Info "版本：$ver"
        return $true
    }

    Write-Step "準備在 WSL2 中安裝 HermesAgent v0.8.0..."
    Write-Host ""
    Write-Warn "安裝約需 15-20 分鐘，請耐心等候。"
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════╗" -ForegroundColor Yellow
    Write-Host "  ║  [提示] 選擇 AI 大腦建議（安裝時會問你）：          ║" -ForegroundColor Yellow
    Write-Host "  ║                                                      ║" -ForegroundColor Yellow
    Write-Host "  ║  方案 A：有 Claude Pro/Max 訂閱                     ║" -ForegroundColor Yellow
    Write-Host "  ║          → 選 Anthropic → Claude Code OAuth         ║" -ForegroundColor Yellow
    Write-Host "  ║          ✅ 吃訂閱額度，不另外付 API 費！            ║" -ForegroundColor Yellow
    Write-Host "  ║                                                      ║" -ForegroundColor Yellow
    Write-Host "  ║  方案 B：有 ChatGPT Plus/Pro 訂閱                   ║" -ForegroundColor Yellow
    Write-Host "  ║          → 選 OpenAI → OpenAI OAuth                 ║" -ForegroundColor Yellow
    Write-Host "  ║          ✅ 吃訂閱額度，不另外付 API 費！            ║" -ForegroundColor Yellow
    Write-Host "  ║                                                      ║" -ForegroundColor Yellow
    Write-Host "  ║  方案 C：想免費試用 → 選 Nous Portal                ║" -ForegroundColor Yellow
    Write-Host "  ║          可免費使用 MiMo 模型兩週                    ║" -ForegroundColor Yellow
    Write-Host "  ║                                                      ║" -ForegroundColor Yellow
    Write-Host "  ║  方案 D：有 OpenRouter / Gemini / 其他 API Key      ║" -ForegroundColor Yellow
    Write-Host "  ║          → 選對應的供應商填入 API Key                ║" -ForegroundColor Yellow
    Write-Host "  ╚══════════════════════════════════════════════════════╝" -ForegroundColor Yellow
    Write-Host ""

    # 官方新網址優先；若無法連線自動 fallback 到 GitHub raw
    $installCmd = "curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash || curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash"
    Write-Highlight "  安裝指令（已複製到剪貼簿）："
    Write-Host "  $installCmd" -ForegroundColor White
    Copy-ToClipboard $installCmd

    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║  安裝步驟：                                          ║" -ForegroundColor Cyan
    Write-Host "  ║  1. 此視窗會自動開啟 WSL2 (Ubuntu) 終端機           ║" -ForegroundColor Cyan
    Write-Host "  ║  2. 指令已在剪貼簿，右鍵貼上後按 Enter              ║" -ForegroundColor Cyan
    Write-Host "  ║  3. 選擇大腦供應商：輸入 1（Nous Portal）按 Enter    ║" -ForegroundColor Cyan
    Write-Host "  ║  4. 複製出現的授權網址，貼到瀏覽器並點 Approve      ║" -ForegroundColor Cyan
    Write-Host "  ║  5. 看到 MiMo Free 畫面後按 Enter                   ║" -ForegroundColor Cyan
    Write-Host "  ║  6. 系統詢問「Launch hermes chat now?」輸入 n        ║" -ForegroundColor Cyan
    Write-Host "  ║  7. 回到此視窗按 Enter                               ║" -ForegroundColor Cyan
    Write-Host "  ╚══════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""

    Pause-Script "  按 Enter 開啟 WSL2 終端機..."

    # 開啟 WSL2 終端機
    try {
        Start-Process "wt.exe" -ArgumentList "wsl" -ErrorAction Stop
    } catch {
        # 若無 Windows Terminal，用傳統方式
        Start-Process "wsl.exe"
    }

    Write-Host ""
    Write-Warn "請在剛開啟的 Ubuntu 視窗中完成 HermesAgent 安裝。"
    Pause-Script "  完成後回到此視窗，按 Enter 繼續..."

    if (Test-HermesInstalled) {
        Write-Ok "HermesAgent 安裝成功！"
        return $true
    } else {
        Write-Warn "無法偵測到 HermesAgent，可能尚未安裝完成。"
        Write-Info "如果確認已安裝，請輸入 Y 繼續；否則按 Enter 重試。"
        $ans = Read-Host "  繼續？(Y/N)"
        return ($ans -eq "Y" -or $ans -eq "y")
    }
}

# ============================================================
#  Phase 3A：設定 Telegram
# ============================================================
function Setup-Telegram {
    Write-Title "Phase 3A：設定 Telegram 機器人"

    Write-Host "  使用 Telegram 無需 ngrok！HermesAgent 支援 Telegram Polling 模式，" -ForegroundColor White
    Write-Host "  只要機器人 Token 正確，隨開即用。" -ForegroundColor White
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║  申請 Telegram 機器人步驟：                          ║" -ForegroundColor Cyan
    Write-Host "  ║                                                      ║" -ForegroundColor Cyan
    Write-Host "  ║  1. 在 Telegram 搜尋 @BotFather                     ║" -ForegroundColor Cyan
    Write-Host "  ║  2. 傳送 /newbot                                     ║" -ForegroundColor Cyan
    Write-Host "  ║  3. 輸入機器人名稱（例：我的愛馬仕助理）             ║" -ForegroundColor Cyan
    Write-Host "  ║  4. 輸入 Username（需以 bot 結尾，例 myhermes_bot） ║" -ForegroundColor Cyan
    Write-Host "  ║  5. 取得 Bot Token（格式：123456:ABCdef...）         ║" -ForegroundColor Cyan
    Write-Host "  ║                                                      ║" -ForegroundColor Cyan
    Write-Host "  ║  取得你的 Telegram User ID：                         ║" -ForegroundColor Cyan
    Write-Host "  ║  1. 在 Telegram 搜尋 @userinfobot                   ║" -ForegroundColor Cyan
    Write-Host "  ║  2. 傳送 /start                                      ║" -ForegroundColor Cyan
    Write-Host "  ║  3. 記下你的 User ID（純數字）                       ║" -ForegroundColor Cyan
    Write-Host "  ╠══════════════════════════════════════════════════════╣" -ForegroundColor Cyan
    Write-Host "  ║  ⭐ 設定完成後的重要步驟：                           ║" -ForegroundColor Cyan
    Write-Host "  ║  在 Telegram 找到你的 Bot 並傳送任意訊息後，         ║" -ForegroundColor Cyan
    Write-Host "  ║  在 WSL2 的 hermes 對話中輸入：/sethome              ║" -ForegroundColor Cyan
    Write-Host "  ║  這樣 Hermes 才知道要把結果回傳到 Telegram！         ║" -ForegroundColor Cyan
    Write-Host "  ╚══════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Pause-Script "  申請完成後按 Enter 輸入資訊..."

    $botToken = ""
    while ($botToken -eq "") {
        $botToken = Read-Host "  請貼入 Telegram Bot Token"
        $botToken = $botToken.Trim()
    }

    $userId = ""
    while ($userId -eq "") {
        $userId = Read-Host "  請貼入你的 Telegram User ID（純數字）"
        $userId = $userId.Trim()
    }

    Write-Step "將 Telegram 設定寫入 WSL2 Hermes 設定..."

    # 先寫暫存檔（避免 Bot Token 含特殊字元爆炸）
    $tmpEnvFile = Join-Path $env:TEMP "hermes_tg_env.txt"
    "TELEGRAM_BOT_TOKEN=$botToken`nTELEGRAM_ALLOWED_USERS=$userId" |
        Set-Content -Path $tmpEnvFile -Encoding UTF8

    # 轉換 Windows 路徑 → WSL 路徑（/mnt/c/...）
    $wslTmpPath = "/mnt/" + ($tmpEnvFile[0].ToString().ToLower()) +
                  ($tmpEnvFile.Substring(2) -replace '\\','/')

    wsl bash -c "mkdir -p ~/.hermes && cat '$wslTmpPath' >> ~/.hermes/.env && echo 'Telegram settings saved'"
    Remove-Item $tmpEnvFile -Force -ErrorAction SilentlyContinue

    Write-Ok "Telegram 設定已儲存！"
    Write-Info "Bot Token: $($botToken.Substring(0,[Math]::Min(15,$botToken.Length)))..."
    Write-Info "User ID: $userId"

    # 儲存狀態
    $state = Load-State
    $state.telegram_set = $true
    $state.telegram_bot_token = $botToken
    $state.telegram_user_id = $userId
    Save-State $state
    return $true
}

# ============================================================
#  Phase 3B：設定 LINE Bridge（Windows 端）
# ============================================================
function Install-NodeJS {
    Write-Step "檢查 Node.js 安裝..."
    Refresh-Path
    $nodeVer = node --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Ok "Node.js 已安裝：$nodeVer"
        return $true
    }

    Write-Step "下載並安裝 Node.js LTS..."

    # 用 winget 安裝（Windows 11 內建）
    try {
        winget install OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
        Refresh-Path
        $nodeVer = node --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Ok "Node.js 安裝完成：$nodeVer"
            return $true
        }
    } catch {}

    Write-Err "Node.js 安裝失敗，請手動安裝後重試："
    Write-Host "  https://nodejs.org/en/download" -ForegroundColor Cyan
    Pause-Script
    return $false
}

function Setup-LineBridge {
    Write-Title "Phase 3B：設定 LINE 機器人橋接器"

    Write-Host "  LINE 橋接原理：" -ForegroundColor White
    Write-Host "  LINE Bot ──→ ngrok 隧道 ──→ LINE Bridge（Windows Port 3000）" -ForegroundColor Gray
    Write-Host "                                    │" -ForegroundColor Gray
    Write-Host "                          HermesAgent（WSL2 Port $HERMES_PORT）" -ForegroundColor Gray
    Write-Host ""

    Write-Host "  ╔══════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║  申請 LINE Bot 步驟：                                ║" -ForegroundColor Cyan
    Write-Host "  ║                                                      ║" -ForegroundColor Cyan
    Write-Host "  ║  1. 前往 LINE Developers Console:                    ║" -ForegroundColor Cyan
    Write-Host "  ║     https://developers.line.biz/                     ║" -ForegroundColor Cyan
    Write-Host "  ║  2. 建立 Provider → 建立 Messaging API Channel       ║" -ForegroundColor Cyan
    Write-Host "  ║  3. Basic settings → 複製 Channel secret             ║" -ForegroundColor Cyan
    Write-Host "  ║  4. Messaging API → 發行 Channel access token        ║" -ForegroundColor Cyan
    Write-Host "  ║  5. 記下 Channel ID（數字）                          ║" -ForegroundColor Cyan
    Write-Host "  ╚══════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Pause-Script "  申請完成後按 Enter 輸入資訊..."

    $channelSecret = ""
    while ($channelSecret -eq "") {
        $channelSecret = Read-Host "  請貼入 LINE Channel Secret"
        $channelSecret = $channelSecret.Trim()
    }

    $channelToken = ""
    while ($channelToken -eq "") {
        $channelToken = Read-Host "  請貼入 LINE Channel Access Token"
        $channelToken = $channelToken.Trim()
    }

    # 確保 bridge 目錄存在
    if (-not (Test-Path $BRIDGE_DIR)) {
        New-Item -ItemType Directory -Path $BRIDGE_DIR | Out-Null
    }

    # 建立 .env 檔
    $envContent = @"
LINE_CHANNEL_SECRET=$channelSecret
LINE_CHANNEL_ACCESS_TOKEN=$channelToken
HERMES_API_URL=http://localhost:$HERMES_PORT/v1/chat/completions
BRIDGE_PORT=$BRIDGE_PORT
"@
    Set-Content -Path (Join-Path $BRIDGE_DIR ".env") -Value $envContent -Encoding UTF8
    Write-Ok "LINE 設定已儲存至 bridge/.env"

    # 安裝 Node.js 依賴
    if (-not (Install-NodeJS)) { return $false }

    Write-Step "安裝 LINE Bridge 依賴套件..."
    Push-Location $BRIDGE_DIR
    npm install --silent
    Pop-Location

    if ($LASTEXITCODE -ne 0) {
        Write-Err "npm install 失敗，請檢查 Node.js 安裝。"
        return $false
    }

    Write-Ok "LINE Bridge 依賴安裝完成！"

    # 儲存狀態
    $state = Load-State
    $state.line_set = $true
    Save-State $state
    return $true
}

# ============================================================
#  Phase 4：安裝與設定 ngrok
# ============================================================
function Install-Ngrok {
    Write-Title "Phase 4：安裝 ngrok（網路隧道工具）"

    if (Test-Path $NGROK_EXE) {
        Write-Ok "ngrok 已安裝：$NGROK_EXE"
        return $true
    }

    Write-Step "嘗試用 winget 安裝 ngrok..."
    try {
        winget install ngrok.ngrok --silent --accept-package-agreements --accept-source-agreements 2>&1
        Refresh-Path
        $ngrokPath = (Get-Command ngrok -ErrorAction SilentlyContinue).Source
        if ($ngrokPath) {
            Write-Ok "ngrok 安裝成功！"
            return $true
        }
    } catch {}

    # 手動下載
    Write-Step "手動下載 ngrok for Windows..."
    try {
        New-Item -ItemType Directory -Force -Path $NGROK_DIR | Out-Null
        $zipPath = Join-Path $env:TEMP "ngrok.zip"
        Invoke-WebRequest -Uri "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip" `
            -OutFile $zipPath -UseBasicParsing
        Expand-Archive -Path $zipPath -DestinationPath $NGROK_DIR -Force
        Remove-Item $zipPath

        # 加到 PATH
        $machinePath = [System.Environment]::GetEnvironmentVariable("Path","Machine")
        if ($machinePath -notlike "*$NGROK_DIR*") {
            [System.Environment]::SetEnvironmentVariable("Path","$machinePath;$NGROK_DIR","Machine")
        }
        Refresh-Path
        Write-Ok "ngrok 下載完成：$NGROK_EXE"
        return $true
    } catch {
        Write-Err "ngrok 下載失敗：$($_.Exception.Message)"
        return $false
    }
}

function Setup-NgrokAuthtoken {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║  取得 ngrok Authtoken：                              ║" -ForegroundColor Cyan
    Write-Host "  ║                                                      ║" -ForegroundColor Cyan
    Write-Host "  ║  1. 前往 https://ngrok.com/ 免費註冊帳號             ║" -ForegroundColor Cyan
    Write-Host "  ║  2. 登入後到 Dashboard → Your Authtoken              ║" -ForegroundColor Cyan
    Write-Host "  ║  3. 複製 Authtoken（格式：2abc...@authtoken）        ║" -ForegroundColor Cyan
    Write-Host "  ╚══════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""

    $authtoken = ""
    while ($authtoken -eq "") {
        $authtoken = Read-Host "  請貼入 ngrok Authtoken"
        $authtoken = $authtoken.Trim()
    }

    try {
        $ngrokExePath = (Get-Command ngrok -ErrorAction SilentlyContinue).Source
        if (-not $ngrokExePath) { $ngrokExePath = $NGROK_EXE }
        & $ngrokExePath config add-authtoken $authtoken
        Write-Ok "ngrok Authtoken 設定完成！"

        $state = Load-State
        $state.ngrok_set = $true
        Save-State $state
        return $true
    } catch {
        Write-Err "ngrok Authtoken 設定失敗：$($_.Exception.Message)"
        return $false
    }
}

# ============================================================
#  Phase 5：啟動服務
# ============================================================
function Start-HermesGateway {
    $state = Load-State
    $mode  = if ($state.install_mode) { $state.install_mode } else { "windows" }

    Write-Title "啟動 HermesAgent Gateway"

    if ($mode -eq "windows") {
        Write-Step "Windows 原生模式：啟動 Gateway..."
        $env:PYTHONUTF8 = "1"

        # 在新視窗執行 hermes gateway run（前景顯示日誌）
        $hermesExe = if (Test-Path $HERMES_WIN_EXE) { $HERMES_WIN_EXE } else { "hermes" }
        Start-Process "cmd.exe" -ArgumentList "/k set PYTHONUTF8=1 && `"$hermesExe`" gateway run" `
            -WindowStyle Normal
        Start-Sleep -Seconds 4
        Write-Ok "Gateway 已在新視窗啟動！（Port: $HERMES_PORT）"
        Write-Info "如遇問題，可加 -vv 參數查看詳細日誌：hermes gateway run -vv"
        return $true
    } else {
        Write-Step "WSL2 模式：啟動 Hermes Gateway..."
        wsl bash -c "hermes gateway start"
        Start-Sleep -Seconds 4

        $statusOut = wsl bash -c "hermes gateway status 2>&1"
        if ($statusOut -match "running|active|started") {
            Write-Ok "Hermes Gateway 已啟動！（Port: $HERMES_PORT）"
            return $true
        } else {
            Write-Warn "Gateway 狀態不確定。"
            Write-Info "可手動在 WSL2 執行：hermes gateway start"
            return $false
        }
    }
}

function Start-LineBridgeService {
    Write-Title "啟動 LINE Bridge（Windows Port $BRIDGE_PORT）"

    $bridgeScript = Join-Path $BRIDGE_DIR "line-bridge.js"
    if (-not (Test-Path $bridgeScript)) {
        Write-Err "找不到 bridge/line-bridge.js！"
        return $false
    }

    # 在新視窗啟動 LINE Bridge（不能用 $args，那是 PS 保留變數）
    $cmdArgs = "/k node `"$bridgeScript`""
    Start-Process "cmd.exe" -ArgumentList $cmdArgs -WindowStyle Normal
    Start-Sleep -Seconds 2
    Write-Ok "LINE Bridge 已在新視窗啟動！（Port $BRIDGE_PORT）"
    return $true
}

function Start-NgrokTunnel {
    param($port = $BRIDGE_PORT, $label = "LINE Bridge")
    Write-Title "啟動 ngrok 隧道 → Port $port（$label）"

    $ngrokExePath = (Get-Command ngrok -ErrorAction SilentlyContinue).Source
    if (-not $ngrokExePath) { $ngrokExePath = $NGROK_EXE }

    # 啟動 ngrok
    Start-Process $ngrokExePath -ArgumentList "http $port" -WindowStyle Normal
    Start-Sleep -Seconds 3

    # 從 ngrok API 取得 URL
    try {
        $tunnels = Invoke-RestMethod "http://localhost:4040/api/tunnels" -ErrorAction Stop
        $url = $tunnels.tunnels | Where-Object { $_.proto -eq "https" } | Select-Object -First 1 -ExpandProperty public_url
        if ($url) {
            Write-Ok "ngrok 隧道已建立！"
            Write-Host ""
            Write-Host "  ╔══════════════════════════════════════════════════════╗" -ForegroundColor Green
            Write-Host "  ║  [網址] 你的公開 Webhook URL：                      ║" -ForegroundColor Green
            Write-Host "  ║" -ForegroundColor Green -NoNewline
            Write-Host "  $url/webhook" -ForegroundColor Yellow -NoNewline
            Write-Host "       ║" -ForegroundColor Green
            Write-Host "  ╚══════════════════════════════════════════════════════╝" -ForegroundColor Green
            Copy-ToClipboard "$url/webhook"
            Write-Host ""
            Write-Host "  請將此 Webhook URL 填入 LINE Developers Console：" -ForegroundColor White
            Write-Host "  Messaging API → Webhook URL → 貼上 → Verify" -ForegroundColor Gray
            return $url
        }
    } catch {}

    Write-Warn "無法自動取得 ngrok URL，請查看 ngrok 視窗。"
    Write-Info "通常格式為：https://xxxx.ngrok-free.app"
    Write-Info "請在 ngrok 視窗中複製 https URL，加上 /webhook 填入 LINE Console"
    return $null
}

# ============================================================
#  一鍵全部安裝
# ============================================================
function Install-Everything {
    Write-Banner
    Write-Host "  開始全自動安裝流程..." -ForegroundColor Cyan
    Write-Host ""

    # 選擇安裝模式
    $mode = Choose-InstallMode

    # Phase 1 & 2：依模式安裝
    $hermesOK = $false
    if ($mode -eq "windows") {
        $hermesOK = Install-HermesWindows
    } else {
        $wsl2OK = Install-WSL2
        if (-not $wsl2OK) { return }
        $hermesOK = Install-HermesInWSL
    }
    if (-not $hermesOK) {
        Write-Err "HermesAgent 安裝未完成，請重試。"
        return
    }

    # Phase 3: 選擇訊息平台
    Write-Title "Phase 3：選擇訊息平台"
    Write-Host "  [T] Telegram（推薦，最簡單，不需 ngrok）" -ForegroundColor White
    Write-Host "  [L] LINE Bot（需要 ngrok 和 LINE Developer 帳號）" -ForegroundColor White
    Write-Host "  [B] 兩個都設定" -ForegroundColor White
    Write-Host ""
    $choice = Read-Host "  請選擇 [T/L/B]"

    $doTelegram = ($choice -match "[TtBb]")
    $doLine     = ($choice -match "[LlBb]")

    if ($doTelegram) { Setup-Telegram | Out-Null }
    if ($doLine)     {
        if (-not (Setup-LineBridge)) {
            Write-Warn "LINE Bridge 設定失敗，繼續其他步驟。"
        }
    }

    # Phase 4: ngrok（LINE 必須 / Telegram Webhook 可選）
    if ($doLine) {
        if (-not (Install-Ngrok)) { return }
        Setup-NgrokAuthtoken | Out-Null
    }

    # Phase 5: 啟動
    Write-Title "Phase 5：啟動所有服務"
    Start-HermesGateway | Out-Null
    if ($doLine) {
        Start-LineBridgeService | Out-Null
        Start-NgrokTunnel -port $BRIDGE_PORT -label "LINE Bridge"
    }

    # 部署知識技能
    Deploy-KnowledgeSkill

    # 完成
    Write-Title "★ 愛馬仕龍蝦安裝完成！"
    Write-Host ""
    if ($doTelegram) {
        Write-Ok "Telegram 機器人已就緒！"
        Write-Host "  → 在 Telegram 找到你的 Bot，傳任意訊息後" -ForegroundColor White
        Write-Host "  → 在 WSL2 hermes 對話中輸入 /sethome（必做！）" -ForegroundColor Yellow
    }
    if ($doLine) {
        Write-Ok "LINE Bridge 已啟動！"
        Write-Info "請確認 Webhook URL 已填入 LINE Developers Console。"
    }
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════╗" -ForegroundColor DarkCyan
    Write-Host "  ║  [指令] 常用指令速查（WSL2 終端執行）：             ║" -ForegroundColor DarkCyan
    Write-Host "  ║                                                      ║" -ForegroundColor DarkCyan
    Write-Host "  ║  hermes gateway start    啟動 Gateway               ║" -ForegroundColor DarkCyan
    Write-Host "  ║  hermes gateway stop     停止 Gateway               ║" -ForegroundColor DarkCyan
    Write-Host "  ║  hermes gateway status   查看狀態                   ║" -ForegroundColor DarkCyan
    Write-Host "  ║  hermes doctor           環境診斷                   ║" -ForegroundColor DarkCyan
    Write-Host "  ║  hermes model            切換 AI 模型               ║" -ForegroundColor DarkCyan
    Write-Host "  ║  hermes update           更新版本                   ║" -ForegroundColor DarkCyan
    Write-Host "  ║                                                      ║" -ForegroundColor DarkCyan
    Write-Host "  ║  [遷移] 從 OpenClaw 龍蝦遷移設定：                  ║" -ForegroundColor DarkCyan
    Write-Host "  ║  hermes claw migrate --dry-run   預覽遷移            ║" -ForegroundColor DarkCyan
    Write-Host "  ║  hermes claw migrate             執行遷移            ║" -ForegroundColor DarkCyan
    Write-Host "  ║                                                      ║" -ForegroundColor DarkCyan
    Write-Host "  ║  ⭐ Telegram 聊天中的重要指令：                      ║" -ForegroundColor DarkCyan
    Write-Host "  ║  /sethome  設定結果回傳頻道（必做！）                ║" -ForegroundColor DarkCyan
    Write-Host "  ║  /new      開新對話                                  ║" -ForegroundColor DarkCyan
    Write-Host "  ║  /skills   瀏覽可用技能                              ║" -ForegroundColor DarkCyan
    Write-Host "  ║  /usage    查看 Token 用量與費用                     ║" -ForegroundColor DarkCyan
    Write-Host "  ║  /voice on 開啟語音模式                              ║" -ForegroundColor DarkCyan
    Write-Host "  ╚══════════════════════════════════════════════════════╝" -ForegroundColor DarkCyan
    Write-Host ""
    Clear-State  # 安裝成功後清除狀態檔
    Pause-Script
}

# ============================================================
#  主選單
# ============================================================
function Show-Menu {
    Write-Banner

    $state = Load-State

    # 快取一次，避免每行呼叫兩次 WSL（慢）
    $wsl2OK   = Test-WSL2
    $hermesOK = Test-HermesInstalled

    Write-Host "  目前狀態：" -ForegroundColor DarkGray
    Write-Host ("  WSL2       :" + (if ($wsl2OK)   { " ✅ 已安裝" } else { " ❌ 未安裝" })) -ForegroundColor (if ($wsl2OK)   { "Green" } else { "Red" })
    Write-Host ("  HermesAgent:" + (if ($hermesOK) { " ✅ 已安裝" } else { " ❌ 未安裝" })) -ForegroundColor (if ($hermesOK) { "Green" } else { "Red" })
    Write-Host ("  ngrok      :" + (if ($state.ngrok_set) { " ✅ 已設定" } else { " — 尚未設定" })) -ForegroundColor (if ($state.ngrok_set) { "Green" } else { "DarkGray" })
    Write-Host ("  Telegram   :" + (if ($state.telegram_set) { " ✅ 已設定" } else { " — 尚未設定" })) -ForegroundColor (if ($state.telegram_set) { "Green" } else { "DarkGray" })
    Write-Host ("  LINE Bridge:" + (if ($state.line_set) { " ✅ 已設定" } else { " — 尚未設定" })) -ForegroundColor (if ($state.line_set) { "Green" } else { "DarkGray" })
    Write-Host ""
    Write-Host "  ═══════════════════════════════════" -ForegroundColor DarkGray
    Write-Host "  [1] 全部安裝（推薦新手）" -ForegroundColor White
    Write-Host "  [2] 安裝 WSL2" -ForegroundColor White
    Write-Host "  [3] 安裝 HermesAgent（在 WSL2）" -ForegroundColor White
    Write-Host "  [4] 設定 Telegram 機器人" -ForegroundColor White
    Write-Host "  [5] 設定 LINE Bridge" -ForegroundColor White
    Write-Host "  [6] 安裝 ngrok + 設定 Authtoken" -ForegroundColor White
    Write-Host "  ═══════════════════════════════════" -ForegroundColor DarkGray
    Write-Host "  [R] 啟動所有服務（hermes gateway start）" -ForegroundColor Yellow
    Write-Host "  [S] 停止 Gateway（hermes gateway stop）" -ForegroundColor Yellow
    Write-Host "  [N] 啟動 ngrok 隧道（LINE）" -ForegroundColor Yellow
    Write-Host "  [D] 執行診斷（hermes doctor）" -ForegroundColor Yellow
    Write-Host "  [W] 開啟 WSL2 Ubuntu 終端機" -ForegroundColor Yellow
    Write-Host "  [Q] 離開" -ForegroundColor DarkGray
    Write-Host "  ═══════════════════════════════════" -ForegroundColor DarkGray
    Write-Host ""
}

# ============================================================
#  程式進入點
# ============================================================
Write-Banner
Write-CopyrightNotice   # 首次啟動顯示著作權聲明

while ($true) {
    Show-Menu
    $choice = Read-Host "  請輸入選項"

    switch ($choice.Trim().ToUpper()) {
        "1" { Install-Everything }
        "2" { Install-WSL2 | Out-Null; Pause-Script }
        "3" { Install-HermesInWSL | Out-Null; Pause-Script }
        "4" { Setup-Telegram | Out-Null; Pause-Script }
        "5" { Setup-LineBridge | Out-Null; Pause-Script }
        "6" {
            Install-Ngrok | Out-Null
            Setup-NgrokAuthtoken | Out-Null
            Pause-Script
        }
        "R" {
            Start-HermesGateway | Out-Null
            $state = Load-State
            if ($state.line_set) { Start-LineBridgeService | Out-Null }
            Pause-Script
        }
        "S" {
            Write-Step "停止 Hermes Gateway..."
            wsl bash -c "hermes gateway stop"
            Write-Ok "Gateway 已停止。"
            Pause-Script
        }
        "D" {
            Write-Title "HermesAgent 診斷（hermes doctor）"
            $diagOut = wsl bash -c "hermes doctor 2>&1"
            Write-Host $diagOut -ForegroundColor White
            Pause-Script
        }
        "N" {
            $state = Load-State
            if ($state.line_set) {
                Start-NgrokTunnel -port $BRIDGE_PORT -label "LINE Bridge"
            } else {
                Start-NgrokTunnel -port $HERMES_PORT -label "Hermes Gateway"
            }
            Pause-Script
        }
        "W" {
            try {
                Start-Process "wt.exe" -ArgumentList "wsl" -ErrorAction Stop
            } catch {
                Start-Process "wsl.exe"
            }
        }
        "Q" {
            Write-Host ""
            Write-Host "  掰掰！愛馬仕龍蝦等你回來 [HermesAgent]" -ForegroundColor Cyan
            Write-Host ""
            break
        }
        default {
            Write-Warn "無效選項，請重新輸入。"
            Start-Sleep -Seconds 1
        }
    }
    if ($choice.Trim().ToUpper() -eq "Q") { break }
}
